/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <xc.h>


#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include <stdio.h>
#include "definitions.h"                // SYS function prototypes


//#include <htc.h>

#include "globals.h"
#include "gbldefines.h"
#include "gblfunctions.h"
#include "lcd.h"
#include "typdef.h"


#define VREFA   (4.932f)

unsigned int calibratedValCenter_ui;
unsigned int calibratedValLow_ui;
unsigned int calibratedValHigh_ui;
unsigned int calibratedValNoise_ui;



int16_t butttonState_u16;
int16_t dv;             // debug
int32_t xx;             // debug
uint16_t raw_data;
float voltage;
char display_value[30]; 


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

static void EIC_ProgramSystem (uintptr_t context)
{
    butttonState_u16 |= programSystemBit;
}
static void EIC_ProgramModify (uintptr_t context)
{
    butttonState_u16 |= programModifyBit;
}
static void EIC_Calibrate (uintptr_t context)
{
    butttonState_u16 |= compileBit;
}



// ************************** Calibration

void CalibrationValues_v(void){
    
    char i;
    calibratedValCenter_ui = 0;    
    calibratedValLow_ui = 0xFFFF;
    calibratedValHigh_ui = 0;
    
    DAC_DataWrite(0x00);  // Turn off LEDs and Pezo
    
     for(i=0; i<10; i++){
        raw_data = ADC0_ConversionResultGet();        
        if (calibratedValLow_ui > raw_data){
            calibratedValLow_ui = raw_data;
        }
        if (calibratedValHigh_ui < raw_data){
            calibratedValHigh_ui = raw_data;
        }        
        calibratedValCenter_ui += raw_data;
        delay_ms(100) ;
     }
    
    calibratedValCenter_ui /= 10 ;    
    calibratedValHigh_ui = calibratedValHigh_ui - calibratedValCenter_ui;
    calibratedValLow_ui  = calibratedValCenter_ui - calibratedValLow_ui;
    
    if (calibratedValHigh_ui > calibratedValLow_ui ){
        calibratedValNoise_ui = calibratedValHigh_ui;
    }
    else {
        calibratedValNoise_ui = calibratedValLow_ui;
    }
    
//    sprintf(display_value, "%0d  %0d  %0d  [%0d]    ", calibratedValCenter_ui, calibratedValLow_ui, calibratedValHigh_ui, calibratedValNoise_ui);
//    LCD_Goto(4, 1);
//    LCD_string(display_value);
  
}

// ************************** main follows:
int main ( void )
{
    
    butttonState_u16 = 0;
    calibratedValCenter_ui = 0;    
    calibratedValLow_ui = 0xFFFF;
    calibratedValHigh_ui = 0;
    
    ALIVE_Clear();

    /* Initialize all modules */
    SYS_Initialize (NULL);
    ADC0_Initialize();
    DAC_Initialize();

    SYSTICK_TimerStart();

    
    LCD_Select(1);
    lcd_init();
    delay_ms(1000);
    
    LCD_Goto(1,1);
    LCD_string("Help Me Spock!"); 

    xx = 0;

    ADC0_Enable();
    
    EIC_CallbackRegister(EIC_PIN_13, EIC_ProgramSystem, 0);
    EIC_CallbackRegister(EIC_PIN_14, EIC_ProgramModify, 0);
    EIC_CallbackRegister(EIC_PIN_15, EIC_Calibrate, 0);
    
    
    LCD_Goto(1, 1);
    LCD_string("  Metal Detector");
    LCD_Goto(2, 1);
    LCD_string("   Version 2.00 ");
    LCD_Goto(3, 1);
    LCD_string("--------------------");
    
    CalibrationValues_v();                  // Put here to take time

//    sprintf(display_value, "%0d  %0d  %0d  [%0d]", calibratedValCenter_ui, calibratedValLow_ui, calibratedValHigh_ui, calibratedValNoise_ui);
//    LCD_Goto(4, 1);
//    LCD_string(display_value);
    
    dv = 0x390;

    
    
    for(;;)
    {
//        SCOPE_Toggle();
        raw_data = ADC0_ConversionResultGet();
        dv = abs(raw_data - 500);
//        while(DAC_IsReady() != true);
        if (DAC_IsReady())
        {
            SCOPE_Toggle();
            DAC_DataWrite(dv);  // DAC is 10 bit 0x3FF  
        }        
//        DAC_DataWrite(dv);  // DAC is 10 bit 0x3FF  
        
        if (butttonState_u16 != 0){
            
            if (butttonState_u16 &= compileBit){
                ALIVE_Toggle();
                CalibrationValues_v();
            }          
            
            delay_ms(500) ;
            butttonState_u16 = 0;    
            
        }
        
    }   
    
    
    for(;;)
    {
//        SCOPE_Toggle();
        raw_data = ADC0_ConversionResultGet();
        dv = abs(raw_data - 160);
        DAC_DataWrite(dv);  // DAC is 10 bit 0x3FF
//        DAC_DataWrite(raw_data/3);  // DAC is 10 bit 0x3FF

        voltage = (float)raw_data * VREFA / 4095;        
        LCD_Goto(2,1);       
        sprintf(display_value, "%d     %d     %f", raw_data, dv, voltage);       
        LCD_string(display_value);
        delay_ms(200);      

    }
 
    
    
    
    for(;;)
    {
        ALIVE_Toggle();
        SCOPE_Toggle();
        dv += 3;
        DAC_DataWrite(dv);  // DAC is 10 bit 0x3FF
        if (dv > 0x03FF)
        {
            dv = 0 ;
        }        
//        delay_ms(200);      
        raw_data = ADC0_ConversionResultGet();
        voltage = (float)raw_data * VREFA / 4095;        
        LCD_Goto(2,1);       
        sprintf(display_value, "%d     %f", raw_data, voltage);       
        LCD_string(display_value);  
        LCD_Goto(3,1);       
        sprintf(display_value, "%lu", xx++);       
        LCD_string(display_value);     
        LCD_Goto(4,1);
        sprintf(display_value, "%x    %x     %d   ", dv, raw_data, abs(raw_data / dv));       
        LCD_string(display_value);          
        

        

//        if(DAC_IsReady() == true)
//        {
//            DAC_DataWrite(raw_data);
//        }
        


        
//        sprintf(display_value, "%lu", xx++);       
//        LCD_Goto(2,1);
//        LCD_string(display_value);
    }
    
    
        


    
    EIC_CallbackRegister(EIC_PIN_13, EIC_ProgramSystem, 0);
    EIC_CallbackRegister(EIC_PIN_15, EIC_ProgramModify, 0);
    EIC_CallbackRegister(EIC_PIN_15, EIC_Calibrate, 0);
        
    ADC0_Initialize();
    ADC0_Enable();
    
    LCD_Select(1);
    lcd_init();

    
    
//    for(;;)
//    {
//            ALIVE_Toggle();
//            SYSTICK_DelayMs(200); 
//    }    

    SYSTICK_DelayMs(200);
    
    while ( true )
    {
//        for(;;)
//        {
////            Alive_Set();
//            ALIVE_Toggle();
//            SYSTICK_DelayMs(1200); 
//        }
        ALIVE_Toggle();
        SYSTICK_DelayMs(2000);

        raw_data = ADC0_ConversionResultGet();
        voltage = (float)raw_data * VREFA / 4095;
        
//        sprintf(display_value, "%d       %f", raw_data, voltage);
//        
//        LCD_Goto(2,1);
//        LCD_string(display_value);
//
//        
//        LCD_Goto(1,1);
//        
//        if (PORT_PinRead(Calibrate_PIN))
//        {
//            LCD_string("Call Pin Pushed");
//        }
//        else {
//            LCD_string("Help Me Spock!");
//        }
        

    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

