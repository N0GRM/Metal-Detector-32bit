/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <xc.h>


#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include <stdio.h>
#include "definitions.h"                // SYS function prototypes


//#include <htc.h>

#include "globals.h"
#include "gblfunctions.h"
#include "lcd.h"
#include "typdef.h"


#define VREFA   (4.932f)

uint16_t raw_data;
float voltage;

char display_value[30]; 


// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

static void EIC_ProgramSystem (uintptr_t context)
{
            ALIVE_Toggle();

//    SCOPE_Set();
//    SCOPE_Clear();
}
static void EIC_ProgramModify (uintptr_t context)
{
            ALIVE_Toggle();

//    SCOPE_Set();
//    SCOPE_Clear();
//    SCOPE_Set();
//    SCOPE_Clear();    

}
static void EIC_Calibrate (uintptr_t context)
{
            ALIVE_Toggle();

//    SCOPE_Set();
//    SCOPE_Clear();
//    SCOPE_Set();
//    SCOPE_Clear();
//    SCOPE_Set();
//    SCOPE_Clear();
}

int32_t xx;
int16_t dv;


int main ( void )
{
    ALIVE_Clear();

    /* Initialize all modules */
    SYS_Initialize (NULL);
    ADC0_Initialize();
    DAC_Initialize();

    SYSTICK_TimerStart();

    
    LCD_Select(1);
    lcd_init();
    delay_ms(1000);
    
    LCD_Goto(1,1);
    LCD_string("Help Me Spock!"); 

    xx = 0;

    ADC0_Enable();
    
    EIC_CallbackRegister(EIC_PIN_13, EIC_ProgramSystem, 0);
    EIC_CallbackRegister(EIC_PIN_14, EIC_ProgramModify, 0);
    EIC_CallbackRegister(EIC_PIN_15, EIC_Calibrate, 0);
    
    dv = 0x390;
    for(;;)
    {
        scope_Toggle();
    }
    
    for(;;)
    {
//        ALIVE_Toggle();
        dv += 3;
        DAC_DataWrite(dv);  // DAC is 10 bit 0x3FF
        if (dv > 0x03FF)
        {
            dv = 0 ;
        }        
        delay_ms(200);      
        raw_data = ADC0_ConversionResultGet();
        voltage = (float)raw_data * VREFA / 4095;        
        LCD_Goto(2,1);       
        sprintf(display_value, "%d     %f", raw_data, voltage);       
        LCD_string(display_value);  
        LCD_Goto(3,1);       
        sprintf(display_value, "%lu", xx++);       
        LCD_string(display_value);     
        LCD_Goto(4,1);
        sprintf(display_value, "%x    %x     %d   ", dv, raw_data, abs(raw_data / dv));       
        LCD_string(display_value);          
        

        

//        if(DAC_IsReady() == true)
//        {
//            DAC_DataWrite(raw_data);
//        }
        


        
//        sprintf(display_value, "%lu", xx++);       
//        LCD_Goto(2,1);
//        LCD_string(display_value);
    }
    
    
        


    
    EIC_CallbackRegister(EIC_PIN_13, EIC_ProgramSystem, 0);
    EIC_CallbackRegister(EIC_PIN_15, EIC_ProgramModify, 0);
    EIC_CallbackRegister(EIC_PIN_15, EIC_Calibrate, 0);
        
    ADC0_Initialize();
    ADC0_Enable();
    
    LCD_Select(1);
    lcd_init();

    
    
//    for(;;)
//    {
//            ALIVE_Toggle();
//            SYSTICK_DelayMs(200); 
//    }    

    SYSTICK_DelayMs(200);
    
    while ( true )
    {
//        for(;;)
//        {
////            Alive_Set();
//            ALIVE_Toggle();
//            SYSTICK_DelayMs(1200); 
//        }
        ALIVE_Toggle();
        SYSTICK_DelayMs(2000);

        raw_data = ADC0_ConversionResultGet();
        voltage = (float)raw_data * VREFA / 4095;
        
//        sprintf(display_value, "%d       %f", raw_data, voltage);
//        
//        LCD_Goto(2,1);
//        LCD_string(display_value);
//
//        
//        LCD_Goto(1,1);
//        
//        if (PORT_PinRead(Calibrate_PIN))
//        {
//            LCD_string("Call Pin Pushed");
//        }
//        else {
//            LCD_string("Help Me Spock!");
//        }
        

    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
*/

