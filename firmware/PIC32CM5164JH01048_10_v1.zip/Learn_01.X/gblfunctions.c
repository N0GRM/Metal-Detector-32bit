/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.c

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#include "definitions.h"                // SYS function prototypes
#include "typdef.h"


void delay_ms(uint16_t ms)
{
    uint16_t t;
    
    for(t=0; t<ms; t++)
    {
//        TC0_TimerStart();
        SYSTICK_TimerStart();
//        while(!TC0_TimerPeriodHasExpired());
        while(!SYSTICK_TimerPeriodHasExpired());
        SYSTICK_TimerStop();
//        TC0_TimerStop();
    }
}