/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

// Variables Follow:

extern unsigned int ii;
extern unsigned int adc;

extern char display_value[30]; 

extern unsigned int calibratedValCenter_ui;
extern unsigned int calibratedValLow_ui;
extern unsigned int calibratedValHigh_ui;
extern unsigned int calibratedValNoise_ui;

extern unsigned int correctedTempValue_ui;

extern unsigned int timeToReadBattery_ui;
extern unsigned int batteryVoltage_ui;

extern char calibratedValOffset_c ;

extern void SpeakerDac_v(unsigned int DACValue_ui);
extern void ZeroSpeakerDac_v( void);
extern unsigned int SetSpeakerByValue_ui(unsigned int spkValue_ui);




